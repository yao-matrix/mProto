#!/bin/bash

. ./common_check.inc

#  INTEL CONFIDENTIAL

# Copyright 2016 Intel Corporation All Rights Reserved.
# The source code contained or described herein and all documents related
# to the source code ("Material") are owned by Intel Corporation or its
# suppliers or licensors. Title to the Material remains with Intel
# Corporation or its suppliers and licensors. The Material may contain
# trade secrets and proprietary and confidential information of Intel
# Corporation and its suppliers and licensors, and is protected by worldwide
# copyright and trade secret laws and treaty provisions. No part of the
# Material may be used, copied, reproduced, modified, published, uploaded,
# posted, transmitted, distributed, or disclosed in any way without
# Intel's prior express written permission.

# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or
# delivery of the Materials, either expressly, by implication, inducement,
# estoppel or otherwise. Any license under such intellectual property rights
# must be express and approved by Intel in writing.

# Unless otherwise agreed by Intel in writing, you may not remove or alter
# this notice or any other notice embedded in Materials by Intel or
# Intel's suppliers or licensors in any way.

usage ()
{
  echo 'Usage : cpufreqpercorepstate.sh  -c|--core core -f|--freq <frequency_in_Khz>	set specific frequency'  
  echo '                  		-r|--reset	reset all core frequency to Pn'
  echo '                  		-h|--help	print this help'
  
}

ARGS=`getopt -o hc:f:r --long help,core:,freq:reset \
             -n 'example.sh' -- "$@"`

if [ $? != 0 ] ; then usage; exit 1 ; fi

# Note the quotes around `$TEMP': they are essential!
eval set -- "$ARGS"

while true; do
    case "$1" in
	 -h|--help)
			usage
			shift
			;;

		-c|--core)
			if [ x$2 != x ]; then
				core=$2
				echo "input core is " $core
			else
				echo "please input the user specific core!"
				exit 1
			fi	
			shift 2
			;;
		 -r|--rest)
			#precheck
			function_check
			function_reset
			disable_C1E_C3_C6
			#set power policy to disableTurbo P1
            cpupower frequency-set -g powersave
            # governor=`cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor`
            # echo "cpupower governor is "$governor

            # disable turbo
            echo 1 > /sys/devices/system/cpu/intel_pstate/no_turbo
            # no_turbo=`cat /sys/devices/system/cpu/intel_pstate/no_turbo`
            # if [ $no_turbo -eq 1 ]
            # then
            #     echo "turbo is diabled successfully."
            # else 
            #     echo "turbo is still enable."
            # fi
                
            # # print out configuration result
            # cpupower frequency-info
            shift
            ;;
         -f|--freq)
			# precheck
			function_check

			# set power policy
			if [ x$2 != x ]; then
				function_reset
				disable_C1E_C3_C6

				echo 0 > /sys/devices/system/cpu/intel_pstate/no_turbo
				
				cpupower idle-set -d 2
				cpupower idle-set -d 3
				cpupower idle-set -d 4
				
				if [ ! $core ]; then 
					cpupower frequency-set -u $2
					cpupower frequency-set -d $2
				else
					
					cpupower -c $core frequency-set -u $2
					cpupower -c $core frequency-set -d $2
					echo "CPU "$core" is be set to "$2"KHZ!"
				fi
			else
				echo "please input the user specific frequency in KHZ!"

				exit 1
			fi
			shift 2
            ;;

        
         -- ) shift; break;;
         * ) echo "unkonw argument"; exit 1;;
    esac
done
