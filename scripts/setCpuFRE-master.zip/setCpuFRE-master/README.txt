CPU Energy Management Command Design and Test Plan

1. powerManagement.sh
This script is used for Ali 6 Case pstate control cases:
Usage : powerManagement.sh -e|--enable                     enable turbo
                        -d|--disable                    disable turbo
                        -f|--freq <frequency_in_khz>    set specific frequency
                        --p1p0n                         set range in p1~p0n
                        --pnp1                          set range in pn~p1
                        --pnp0u <frequency_in_khz>      set range in pn~p0u user specific turbo limit
                        -h|--help       print this help


2. cpufreqpercorepstate.sh
This script can control the cpu frequency per core use intel_pstate driver.
Before use it, you should apply one patch to your machine.
This link contains two files:
http://spandruv-powerlab-build.jf.intel.com/export/images/perc-limits/

1)
0001-cpufreq-intel_pstate-Per-thread-P-State-limits.patch

A patch which can be applied to latest Linux stable release 4.7.5.

Refer to this file about the usage and test cases.

2)
linux-image-4.7.5+_4.7.5+-1_amd64.deb

This is ubuntu 15.10 prebuilt kernel image. You can install

# dpkg -i linux-image-4.7.5+_4.7.5+-1_amd64.deb

It should also work in Ubuntu other versions also.

[root@chinarack-wcp setCpuFre]# ./cpufreqpercorepstate.sh -h
Usage : cpufreqpercorepstate.sh  -c|--core core -f|--freq <frequency_in_Khz>     set specific frequency
                                -r|--reset      reset all core frequency to Pn
                                -h|--help       print this help


3. cpufreqpercoremsr.sh
This script change msr directly to control the cpu frequency by EIST. Not recommand to edit the msr directly if intel_pstate is working.
Usage : cpufreqpercoremsr.sh  [-c|--core] core -f|--freq <frequency_in_Mhz>   set specific frequency
                                -r|--reset      reset all core frequency to Pn
                                -h|--help       print this help


